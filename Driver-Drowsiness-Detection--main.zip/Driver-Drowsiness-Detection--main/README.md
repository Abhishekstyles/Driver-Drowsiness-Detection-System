# Driver-Drowsiness-Detection-
In this Python project, I created a drowsy driver alert system  that can be used to detect drowsiness of a person .I have used OpenCV  and dlib library to detect  faces and eyes, and then a CNN model to predict the state. The  model was enhanced by adding additional datasets, which were  used to train and test the model with different iterations.
There are three different functionalities of this project-
1.Run App.py to run the streamlit web app.
2.Run final_webcamp.py to detect drowsiness using pc or laptop camera.
3.Run Detection_using_Phone.py to detect drowsiness using your mobile phone.To detect drowsiness using phone, Webcam Ip app need to be installed on mobile phone.
